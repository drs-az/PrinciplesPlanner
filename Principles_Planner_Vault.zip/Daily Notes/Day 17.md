# Day 17

Prev: [[Day 16]]  
Next: [[Day 18]]  

### 17 – Core Principle: MASTER YOUR EMOTIONS

**Morning Intention:** Respond, don’t react—keep judgment clear under pressure.  

**Exercises:**

1. Use a 90-second pause protocol before any hard conversation or reply.  

2. Name the dominant emotion you feel today and the need beneath it.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: