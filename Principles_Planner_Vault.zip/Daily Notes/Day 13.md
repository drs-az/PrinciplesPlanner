# Day 13

Prev: [[Day 12]]  
Next: [[Day 14]]  

### 13 – Core Principle: SERVE A GREATER GOOD

**Morning Intention:** Let quiet service define you—do good without audience.  

**Exercises:**

1. Perform a helpful act anonymously today.  

2. Connect your daily work to real value delivered; write one sentence describing it.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: