# Day 19

Prev: [[Day 18]]  
Next: [[Day 20]]  

### 19 – Core Principle: NEVER STOP LEARNING

**Morning Intention:** Stay a student—curiosity plus practice makes you antifragile.  

**Exercises:**

1. Read 20 pages and capture 5 notes in your commonplace book.  

2. Start a 6-week skill sprint; define the weekly deliverable.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: