# Day 25

Prev: [[Day 24]]  
Next: [[Day 26]]  

### 25 – Core Principle: SHOW RESPECT AND COMPASSION

**Morning Intention:** Let your presence lower the temperature, not raise it.  

**Exercises:**

1. Remove sarcasm and contempt from all communication today.  

2. Do a small, concrete kindness for someone with no leverage.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: