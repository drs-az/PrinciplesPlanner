# Day 62

Prev: [[Day 61]]  
Next: [[Day 63]]  

### 62 – Core Principle: NEVER STOP LEARNING

**Morning Intention:** Convert input to output—teach what you learn.  

**Exercises:**

1. Ship a small artifact today (thread, memo, demo) distilling a lesson.  

2. Seek one opposing viewpoint; summarize it fairly before debating.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: