# Day 26

Prev: [[Day 25]]  
Next: [[Day 27]]  

### 26 – Core Principle: CHERISH FAMILY AND COMMUNITY

**Morning Intention:** Be reliably present where you’re irreplaceable.  

**Exercises:**

1. Schedule a family ritual this week (meal, walk, game); protect it.  

2. Handle an unglamorous task at home without being asked.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: