# Day 72

Prev: [[Day 71]]  
Next: [[Day 73]]  

### 72 – Core Principle: EMBRACE ADVERSITY

**Morning Intention:** Move from complaint to construction.  

**Exercises:**

1. For a setback, draft a simple plan: next right action + earliest time block.  

2. Practice gratitude under strain: write five items you’re thankful for today.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow:

See: [[Weekly Review 10]]