# Day 45

Prev: [[Day 44]]  
Next: [[Day 46]]  

### 45 – Core Principle: STAND BY YOUR PRINCIPLES

**Morning Intention:** Act from your core values, not convenience—choose the principled path.  

**Exercises:**

1. Write your top 5 non-negotiables; carry them with you today.  

2. Make one decision today based purely on principle, even if it costs.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: