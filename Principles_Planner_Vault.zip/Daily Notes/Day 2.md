# Day 2

Prev: [[Day 1]]  
Next: [[Day 3]]  

### 2 – Core Principle: OWN YOUR WORD

**Morning Intention:** Focus on micro-commitments—match your speech precisely to your actions.  

**Exercises:**

1. Audit yesterday’s conversations; send follow-ups or corrections for anything unclear.  

2. Practice precise yes/no responses; avoid vague hedging or soft promises.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: