# Day 11

Prev: [[Day 10]]  
Next: [[Day 12]]  

### 11 – Core Principle: EMBRACE RESPONSIBILITY

**Morning Intention:** Model accountability—repair what you can without theatrics.  

**Exercises:**

1. Offer a clean apology where you dropped the ball (no 'but'); propose a fix.  

2. Tie any request for authority to demonstrated contribution today.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: