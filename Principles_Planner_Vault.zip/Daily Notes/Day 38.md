# Day 38

Prev: [[Day 37]]  
Next: [[Day 39]]  

### 38 – Core Principle: MENTOR AND ELEVATE OTHERS

**Morning Intention:** Multiply good—turn experience into someone else’s shortcut.  

**Exercises:**

1. Hold a focused 1:1 with a mentee; set one measurable goal together.  

2. Make an introduction that unlocks an opportunity for someone.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: