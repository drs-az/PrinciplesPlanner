# Day 4

Prev: [[Day 3]]  
Next: [[Day 5]]  

### 4 – Core Principle: STAND BY YOUR PRINCIPLES

**Morning Intention:** Pre-commit under pressure—decide now where you won’t compromise.  

**Exercises:**

1. Use 'Even if…' language in a relevant conversation to clarify your stand.  

2. Decline one option that conflicts with your values, and note the relief gained.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: