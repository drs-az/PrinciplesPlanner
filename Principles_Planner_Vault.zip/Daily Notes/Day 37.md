# Day 37

Prev: [[Day 36]]  
Next: [[Day 38]]  

### 37 – Core Principle: LEAD BY EXAMPLE

**Morning Intention:** Small signals build culture—sweat the visible details.  

**Exercises:**

1. Choose one small, public act that demonstrates the norm (cleanup, note of thanks).  

2. Document the standard you expect; follow it first.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow:

See: [[Weekly Review 5]]