# Day 5

Prev: [[Day 4]]  
Next: [[Day 6]]  

### 5 – Core Principle: STAY HUMBLE

**Morning Intention:** Lead with curiosity; be teachable in every room you enter.  

**Exercises:**

1. Ask one trusted person for candid feedback on a recent decision.  

2. Give public credit to someone whose work deserves recognition.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: