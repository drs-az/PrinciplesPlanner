# Day 75

Prev: [[Day 74]]  
Next: [[Day 76]]  

### 75 – Core Principle: ADAPT AND OVERCOME

**Morning Intention:** Flex the plan, not the standard—update quickly.  

**Exercises:**

1. Run a pre-mortem on a key task; prepare a simple Plan B.  

2. Take the smallest viable next step on a stalled initiative.  


**Midday Check-In:** Alignment score [  ] – What’s helping me stay on track?  

**Evening Reflection:** Did I act in alignment? [Yes/No] – Where did I drift? – Lesson for tomorrow: