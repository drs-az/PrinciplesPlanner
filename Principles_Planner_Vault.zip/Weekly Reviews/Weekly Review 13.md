# Weekly Review 13

**What went well?**  
**What could have gone better?**  
**How will I improve next week?**
