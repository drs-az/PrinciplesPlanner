# Weekly Review 40

**What went well?**  
**What could have gone better?**  
**How will I improve next week?**
