# Weekly Review 5

**What went well?**  
**What could have gone better?**  
**How will I improve next week?**
