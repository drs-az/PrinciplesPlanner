# Weekly Review 47

**What went well?**  
**What could have gone better?**  
**How will I improve next week?**
