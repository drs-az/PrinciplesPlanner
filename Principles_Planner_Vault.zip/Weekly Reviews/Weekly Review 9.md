# Weekly Review 9

**What went well?**  
**What could have gone better?**  
**How will I improve next week?**
