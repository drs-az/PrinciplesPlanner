# Weekly Review 46

**What went well?**  
**What could have gone better?**  
**How will I improve next week?**
